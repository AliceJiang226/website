document.getElementById('helloBtn').addEventListener('click', function() {
    alert('Hello from your new website!');
});

function flipCard(card) {
    card.classList.toggle('flipped');
}
